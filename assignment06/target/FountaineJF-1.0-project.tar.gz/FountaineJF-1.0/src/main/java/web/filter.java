package web;

import javax.servlet.*;
import javax.servlet.http.HttpServletResponse;
import javax.xml.transform.*;
import javax.xml.transform.stream.StreamSource;
import java.io.*;

public class filter implements Filter {


    private ServletContext ctx;

    public void init(FilterConfig filterCfg) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        final CharResponseWrapper responseWrapper = new CharResponseWrapper((HttpServletResponse) response);
        if (!(response instanceof HttpServletResponse)) {
            chain.doFilter(request, responseWrapper);
            return;
        }

        StringReader reader = new StringReader(responseWrapper.toString());
        Source xmlSource = new StreamSource(reader);

        StringWriter output = new StringWriter();
        String format = request.getParameter("format");
        StringBuilder builder = new StringBuilder();

        if (!format.equals("xml")) {
            switch (format) {
                case "plain":
                    response.setContentType("text/Plain");
                    builder.append("\"Symbol\":\"" + reader + "symbol" + ",\"\r\n");
                    builder.append("\"Price\":\"" + "price" + "\"\r\n");
                    break;
                case "json":
                    response.setContentType("text/Json");
                    builder.append("\"Symbol\":\"" + "symbol" + ",\"\r\n");
                    builder.append("\"Price\":\"" + "price" + "\"\r\n");
                    break;
                case "html":
                    response.setContentType("text/html");
                    builder.append("\"Symbol\":\"" + "symbol" + ",\"\r\n");
                    builder.append("\"Price\":\"" + "price" + "\"\r\n");
                    break;
            }
        }
        output.append(builder.toString());
        String respStr = output.toString();
        response.setContentLength(respStr.length());
        response.getWriter().write(output.toString());
    }

    @Override
    public void destroy() {

    }
}
